//
//  ProfilePictureView.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 24/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation
import SwiftUI

struct ProfilPictureView : View
{
    var picture: String
    var size : CGFloat = 80
    
    var body : some View
    {
        Image(picture)
        .resizable()
        .aspectRatio(contentMode: .fill)
        .frame(width: size, height: size)
        .clipShape(Circle())
        .overlay(
        Circle().stroke(Color.white, lineWidth: 1))
        .shadow(radius:2)
        
    }
}

//
//  EndLow.swift
//  CreaCorp Yv
//
//  Created by Yves MARTIN on 21/02/2020.
//  Copyright © 2020 Yves MARTIN. All rights reserved.
//

import SwiftUI


// End Low
struct EndLow: View {
    @EnvironmentObject var user: User
    
    @State var showImagePicker: Bool = false
    @State var showLogoPicker: Bool = false

    

    @State var userProjectName: String = ""
    @State var userProjectDescript: String = ""
    @State var userProjectWebsite: String = ""
    
    
    var body: some View {
        VStack {
            
            // ---------------------------------------
            VStack {
                Spacer(minLength: 10)

                                Button(action: {
                                    withAnimation {
                                        self.showImagePicker.toggle()
                                    }
                                }) {
                
                                    if user.userImageDL != nil {
                                        Text("Changer ma photo").foregroundColor(Color(red: 54/255, green: 134/255, blue: 247/255))
                                    }else{
                                        Text("Ma photo").foregroundColor(Color(red: 54/255, green: 134/255, blue: 247/255))
                                    }
                                }
                                .sheet(isPresented: $showImagePicker) {
                                    ImagePicker(image: self.$user.userImageDL)
                                }
                
                
                ZStack{
                    Circle()
                        .fill(Color.white)
                        .frame(width: 127, height: 127)
                        .overlay(Circle().stroke(lineWidth: 2))
                        .gesture(
                            TapGesture()
                                .onEnded { _ in
                                    self.showImagePicker.toggle()
                            }
                    )
                    
                    Image (systemName: "person.crop.circle.badge.plus")
                        .scaleEffect(1.5)
                    
                    user.userImageDL?.resizable()
                        .frame(width: 127, height: 127)
                        .clipShape(Circle())
                        //.shadow(radius: 10)
                        .overlay(Circle().stroke(Color(red: 54/255, green: 134/255, blue: 247/255),lineWidth: 2))
                    
                    
                }
                .foregroundColor(Color(red: 54/255, green: 134/255, blue: 247/255))
                
            }
            
            Spacer(minLength: 20)
            HStack {
                Text("Nom du Projet / Entreprise")
                Spacer()
            }
            VStack {
                TextField("Nom du Projet / Entreprise", text: $user.userProjectName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    //                    .padding(.leading, 5.0)
                    //                    .border(Color.gray)
                    //                    .keyboardType(/*@START_MENU_TOKEN@*/.default/*@END_MENU_TOKEN@*/)
                    .font(.headline)
            }
            .padding(.top, -10.0)
            .font(.title)
            HStack {
                Text("Description")
                    .lineLimit(/*@START_MENU_TOKEN@*/2/*@END_MENU_TOKEN@*/)
                Spacer()
            }
            VStack {
                TextField("Décrivez votre projet en quelques mots", text: $user.userProjectDescription)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    //                    .lineLimit(4)
                    //                    .multilineTextAlignment(.leading)
                    //                    .frame(minWidth: 100, maxWidth: 400, minHeight: 20, maxHeight: 100, alignment: .topLeading)
                    //                    .padding(.leading, 5.0)
                    //                    .border(Color.gray)
                    //                    .keyboardType(/*@START_MENU_TOKEN@*/.default/*@END_MENU_TOKEN@*/)
                    .font(.headline)
            }
            .padding(.top, -10.0)
            .font(.title)
            HStack {
                Text("WebSite")
                Spacer()
            }
            
            VStack {
                TextField("Votre WebSite", text: $user.userProjectWebsite)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    //                    .padding(.leading, 5.0)
                    //                    .border(Color.gray)
                    //                    .keyboardType(/*@START_MENU_TOKEN@*/.default/*@END_MENU_TOKEN@*/)
                    .font(.headline)
            }
            .padding(.top, -10.0)
            .font(.title)
            
            
            
            
            VStack {
                Spacer(minLength: 10)

                                Button(action: {
                                    withAnimation {
                                        self.showLogoPicker.toggle()
                                    }
                                }) {
                
                                    if user.userProjectLogoDL != nil {
                                        Text("Changer mon logo").foregroundColor(Color(red: 54/255, green: 134/255, blue: 247/255))
                                    }else{
                                        Text("Mon logo").foregroundColor(Color(red: 54/255, green: 134/255, blue: 247/255))
                                    }
                                }
                                .sheet(isPresented: $showLogoPicker) {
                                    ImagePicker(image: self.$user.userProjectLogoDL)
                                }
                
                
                ZStack{
                    Circle()
                        .fill(Color.white)
                        .frame(width: 127, height: 127)
                        .overlay(Circle().stroke(lineWidth: 2))
                        .gesture(
                            TapGesture()
                                .onEnded { _ in
                                    self.showLogoPicker.toggle()
                            }
                    )
                    
                    Image (systemName: "photo.fill")
                        .scaleEffect(1.5)
                    
                    user.userProjectLogoDL?.resizable()
                        .frame(width: 127, height: 127)
                        .clipShape(Circle())
                        //.shadow(radius: 10)
                        .overlay(Circle().stroke(Color(red: 54/255, green: 134/255, blue: 247/255),lineWidth: 2))
                    
                    
                }
                .foregroundColor(Color(red: 54/255, green: 134/255, blue: 247/255))
                
            }
            
            Spacer(minLength: 20)
            
            
            

        }
    }
    
    struct EndLow_Previews: PreviewProvider {
        static var previews: some View {
            EndLow()
                .environmentObject(User.yves)
        }
    }
    
}

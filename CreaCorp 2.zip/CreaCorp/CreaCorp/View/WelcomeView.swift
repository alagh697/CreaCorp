//
//  WelcomeView.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 20/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation
import SwiftUI

struct WelcomeView : View
{
    var user : User
    
    @ObservedObject private var kGuardian = KeyboardGuardian(textFieldCount: 1)
    
    
    var body : some View
    {
        VStack(alignment: .center, spacing: 15)
        {
            Image("CreaCorp")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(height: 250, alignment: .top)
            
            LoginView(theUser: user)
            
            
            
            NavigationLink(destination: MatchingView(user: user))
            {
                Text("Connexion").bold().font(.title)
                .padding(10)
                .foregroundColor(.white)
                .background(Color.blue)
                .cornerRadius(10)
                .shadow(radius:4)
            }.buttonStyle(PlainButtonStyle())
            
            
            NavigationLink(destination: InscriptionView(user: user))
            {
                Text("Inscription").bold().font(.title)
                .padding(10)
                .foregroundColor(.white)
                .background(Color.blue)
                .cornerRadius(10)
                .shadow(radius:4)
                
            }.buttonStyle(PlainButtonStyle())
        }.padding()
        
        
    }
}

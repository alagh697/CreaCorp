//
//  HeaderMid.swift
//  CreaCorp Yv
//
//  Created by Yves MARTIN on 21/02/2020.
//  Copyright © 2020 Yves MARTIN. All rights reserved.
//

import SwiftUI


// Header middle
struct HeaderMid: View {
    @Binding var userProfileType: String
    
    //@Binding var userProfileType: String
    var body: some View {
        Picker(selection: $userProfileType, label: Text("Choice")
            .font(.title)) {
                Text("DEMANDEUR").tag("Demandeur")
                Text("MENTOR").tag("Mentor")
        }
        .frame(width: 350.0, height: 20.0)
        .pickerStyle(SegmentedPickerStyle())
        .padding()
    }
}

struct HeaderMid_Previews: PreviewProvider {
    static var previews: some View {
        return HeaderMid(userProfileType: .constant("Mentor"))
    }
}



//
//  HeaderInf.swift
//  CreaCorp Yv
//
//  Created by Yves MARTIN on 21/02/2020.
//  Copyright © 2020 Yves MARTIN. All rights reserved.
//

import SwiftUI


// Header inférieur
struct HeaderInf: View {
    let userProfileType: String
    
    init(userProfileType: String) {
        self.userProfileType = userProfileType
    }
    
    func sentence(userProfileType: String) -> String {
        return userProfileType == "Demandeur" ? "Je souhaite un accompagnement pour :" : "Je propose un accompagnement pour :"
    }
    var body: some View {
        Text(sentence(userProfileType: userProfileType))
            .font(.body)
            .fontWeight(.bold)
            .frame(width: 350.0, height: 20.0)
            .pickerStyle(SegmentedPickerStyle())
            .padding()
    }
}
struct HeaderInf_Previews: PreviewProvider {
    static var previews: some View {
        HeaderInf(userProfileType: User.yves.userProfileType)
    }
}


//
//  MatchingView.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 20/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation
import SwiftUI

struct MatchingView : View
{
    var user : User
    
    var body : some View
    {
        
        VStack
        {
            Text("")
                .navigationBarTitle("Matching")
                .navigationBarItems(leading: NavigationLink(destination: ProfilDetailView(user: user))
                {
                    ButtonImageView(iconLink: "person.circle.fill", opacityVal: 1)
                    
                }.buttonStyle(PlainButtonStyle()),
                trailing: NavigationLink(destination: ChatroomListView(user: user))
                {
                    ButtonImageView(iconLink: "message.circle.fill", opacityVal: 1)
                    
                }.buttonStyle(PlainButtonStyle()))
            
            List {
                ForEach(matchings) { match in
                    
                    if(match.user.userProfileType != userAlaaeddine.userProfileType)
                    {
                        NavigationLink(destination:ProfilDetailView(user: match.user))
                        {
                            
                            ContentRow(match: match)
                        
                        }
                        
                    }
                    
                    
                    
                }.onDelete(perform: deleteItems)
            }
                
        }.navigationBarTitle(Text("Matching"), displayMode: .large)
    }
    
    func deleteItems(at offsets: IndexSet)
    {
        matchings.remove(atOffsets: offsets)
    }
}

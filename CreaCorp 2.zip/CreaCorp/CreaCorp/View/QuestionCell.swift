//
//  QuestionCell.swift
//  CreaCorp Yv
//
//  Created by Yves MARTIN on 21/02/2020.
//  Copyright © 2020 Yves MARTIN. All rights reserved.
//

import SwiftUI

// SubView : 1 Question Cell

// fonction pour bouton de test d'une variable
// Question List =========================
//       func checkAnswer(question: Question) {
//            print(question.answer)
//        }
//

//class QuestionCell: Identifiable, ObservableObject {
//

struct QuestionCell: View {
    @Binding var question: Question
    @EnvironmentObject var currentUser: User
    
    
    var body: some View {
        HStack {
            Spacer()
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .frame(height: 130)
                    //                .frame(width: 360)
                    .foregroundColor(.gray)
                    .opacity(0.2)
                VStack {
                    HStack {
                        Text("  \(question.label)")
                        Spacer()
                    }
                    
                    //0..<topics.count
                    ForEach(question.topics.indices) { i in
                        HStack {
                            Text("  \(self.question.topics[i])")
                            Spacer()
                        }
                    }
                    
                    
                    Picker(selection: self.$question.answer, label: Text("Choice")
                        .font(.footnote)) {
                            Text("OUI").tag("OUI")
                            Text("NON").tag("NON")
                    }
                    .frame(height: 20.0)
                    .pickerStyle(SegmentedPickerStyle())
                    .foregroundColor(.blue)
                    .id(UUID().uuidString)
                }
            }
            .frame(width: 350)
            Spacer()
         
        }
    }
}


//Preview  1 Question Cell ; w/ fake values
struct QuestionCell_Previews: PreviewProvider {
    
    static var previews: some View {
        let questionExample: Question = Question(id: 0, label: "W", topics: ["a", "b", "c"], answer: "")
        return QuestionCell(question: .constant(questionExample))
        
    }
}


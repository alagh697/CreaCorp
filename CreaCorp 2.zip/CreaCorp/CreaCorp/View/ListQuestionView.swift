//
//  ListQuestionView.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 25/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

//
//  ContentView.swift
//  CreaCorp Yv
//
//  Created by Yves MARTIN on 17/02/2020.
//  Copyright © 2020 Yves MARTIN. All rights reserved.
//

import SwiftUI


// SubView : Question List
class Question: Identifiable {
    let id: Int
    let label: String
    let topics: [String]
    var answer: String
    
    init(id: Int, label: String, topics: [String], answer: String = "") {
        self.id = id
        self.label = label
        self.topics = topics
        self.answer = answer
    }
}

class QuestionList: ObservableObject {
    
    @Published var questionArray: [Question] = [
        Question(id:1, label: "Domaine d’activité :", topics: ["- Pourquoi le cibler ?", "- Marchés / Produits","- Facteurs clés de succès"]),
        Question(id:2, label: "Définition Produits :", topics: ["- Quoi ?", "- Pour quoi ?", "- Comment ?"]),
        Question(id:3, label: "Définition Marchés :", topics: ["- Type de clients", "- Localisation","- Canaux de distribution"]),
        Question(id:4, label: "Position Concurrentielle :", topics: ["- Savoir-faire attendus", "- Savoir-faire maitrisés et manquants", "- Forces et faiblesses vs concurrents"]),
        Question(id:5, label: "Attractivité du Marché : 1/2 :", topics: ["- Taux de croissance", "- Intensité concurrentielle","- Risque de substitut"]),
        Question(id:6, label: "Attractivité du Marché : 2/2 :", topics: ["- Pouvoir de négociation des clients", "- Pouvoir de négociation des fournisseurs", "- Barrières à l’entrée"]),
        Question(id:7, label: "Cadre de référence du dirigeant :", topics: ["- Finalités & Ethique", "- Histoire & Culture","- Métier & Intérêt stratégique"]),
        Question(id:8, label: "Financement :", topics: ["- Recherche d’aides publiques et privées", "- Montage du plan de financement", "- Validation du prévisionnel et banques"]),
        Question(id:9, label: "Aspects administratifs :", topics: ["- Protection juridique et intellectuelle", "- Fiscal & social","- Réglementaire"]),
        Question(id:10, label: "Dossiers & Présentations :", topics: ["- Business Plan", "- Executive Summary", "- Pitch"])
    ]
    
    func convertQuestionToAnswer() -> [String] {
        var answers: [String] = []
        for question in self.questionArray {
            answers.append(question.answer)
        }
        return answers
    }
}



//Data for Cells
struct ListQuestionView: View {
    @EnvironmentObject var user: User
    @EnvironmentObject var questionList: QuestionList
    
    var body: some View {
 
        List {
            
            ForEach(self.questionList.questionArray.indices) { index in
                QuestionCell(question: self.$questionList.questionArray[index])
            }

            EndHigh()
            EndLow()
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .frame(height: 50)
                    .foregroundColor(.clear)
                    .opacity(0.2)
                HStack(alignment: .center, spacing: 135.0) {
                    Spacer()
                    NavigationLink(destination: MatchingView(user: userAlaaeddine)) {
                        ButtonTextView(btText: "Validation", backColor: .blue)
                            .multilineTextAlignment(.trailing)
                        
                        // zone à cliquer pour changement de page
                    }
                }
            }
        }
    }
}

func checkValue(user: User) {
    print(user.userAnsQ1)
}


// Preview Data for Cells
struct ListQuestionView_Previews: PreviewProvider {
    static var previews: some View {
        ListQuestionView()
            .environmentObject(User.yves)
            .environmentObject(QuestionList())
        
    }
}




//
//  Shadow.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 26/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation
//
//  Shadow.swift
//  CreaCorp Yv
//
//  Created by Yves MARTIN on 26/02/2020.
//  Copyright ©️ 2020 Yves MARTIN. All rights reserved.
//

import SwiftUI

struct SeparateShadow: View {
    var body: some View {
        Rectangle()
            .frame(width: 415, height: 1)
            .shadow(radius: 1)
            .foregroundColor(.gray)
    }
}

struct SepararteShadow_Previews: PreviewProvider {
    static var previews: some View {
        SeparateShadow()
    }
}

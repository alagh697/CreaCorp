//
//  ChatroomListView.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 20/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation
import SwiftUI

struct ChatroomListView : View
{
    var user : User
    
    var body : some View
    {
        VStack
        {
            ScrollView(.horizontal, showsIndicators: false, content: {
                HStack(spacing: 10)
                {
                    ForEach(usersSample) { aUser in
                    
                        NavigationLink(destination:ProfilDetailView(user: aUser))
                        {
                            
                            ProfilPictureView(picture: aUser.userImage, size: 60)
                        }.buttonStyle(PlainButtonStyle())
                    }
                }.padding(.leading, 10)
            }).frame(height: 100)
            
            Text("")
            .navigationBarTitle("Discussions")
                .navigationBarItems(trailing: NavigationLink(destination: NewsFeedView(user: user))
                {
                    ButtonImageView(iconLink: "calendar.circle.fill", opacityVal: 1)
                        
                }.buttonStyle(PlainButtonStyle()))
            
            List
            {
                ForEach(chatSample) { chat in
                    
                    NavigationLink(destination:ChatDetailView(chat: chat, user: self.user))
                    {
                        
                        ChatRow(chat: chat)
                    
                    }
                }
            }
            
        }
        
        
    
    }
}

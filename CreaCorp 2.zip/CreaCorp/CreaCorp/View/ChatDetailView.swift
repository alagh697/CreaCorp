//
//  ChatDetailView.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 24/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation

import SwiftUI

struct ChatDetailView: View
{
    
    
    
    @State var chat : Chat
    var user : User
    
    @State var newMessageText = ""
    
    @ObservedObject private var kGuardian = KeyboardGuardian(textFieldCount: 1)

    
    
    var body : some View
    {
        
        VStack(alignment: .leading, spacing: 5)
        {
            
            Text("")
                .navigationBarItems(trailing: NavigationLink(destination: ProfilDetailView(user: chat.chatAdmin))
                {
                    HStack
                    {
                        ProfilPictureView(picture: chat.chatAdmin.userImage, size: 40)
                        Text("\(chat.chatAdmin.userFirstName) \(chat.chatAdmin.userLastName)").bold()
                    }
                }.buttonStyle(PlainButtonStyle()))
            
            List
            {
                ForEach(chat.chatMessages)
                { message in
                    
                HStack
                {
                    if message.messageSender.userFirstName == self.user.userFirstName
                    {
                        Spacer()
                        ButtonTextView(btText: message.messageText, backColor: .blue)
                        
                    }
                    else
                    {
                        ProfilPictureView(picture: message.messageSender.userImage, size: 35)
                        ButtonTextView(btText: message.messageText, backColor: .gray)
                    }
                }
            
                }
            }
            
            HStack
            {
//                TextField("Some Text" , text: $newMessageText).modifier(ClearButton(text: $newMessageText))

                
                TextField("Aa ", text: $newMessageText)
                .padding(5)
                .background(Color.gray)
                .foregroundColor(.white)
                .opacity(0.9)
                .cornerRadius(10)
                
                Button (action: {
                    self.chat.addMessage(message: Message(messageSender: self.user, messageReceiver: usersSample[0], messageText: self.newMessageText))
                    self.newMessageText=""
                    
                })
                {
                    ButtonImageView(iconLink: "paperplane.fill", opacityVal: 1)
                        
                    
                }.buttonStyle(PlainButtonStyle())
                .disabled(self.newMessageText.isEmpty)
                
            }.padding()
            .background(GeometryGetter(rect: $kGuardian.rects[0]))
            
            
            
            
        }.offset(y: kGuardian.slide).animation(.easeInOut(duration: 0.5))
            .onAppear() {
                self.kGuardian.addObserver()
                UITableView.appearance().separatorStyle = .none
            }
            .onDisappear() {
                self.kGuardian.removeObserver()
                UITableView.appearance().separatorStyle = .singleLine
            }
    }
}

struct ClearButton: ViewModifier
{
    @Binding var text: String

    public func body(content: Content) -> some View
    {
        ZStack(alignment: .trailing)
        {
            content

            if !text.isEmpty
            {
                Button(action:
                {
                    self.text = ""
                })
                {
                    Image(systemName: "delete.left")
                        .foregroundColor(Color(UIColor.opaqueSeparator))
                }
                .padding(.trailing, 8)
            }
        }
    }
}

//
//  EndHigh.swift
//  CreaCorp Yv
//
//  Created by Yves MARTIN on 21/02/2020.
//  Copyright © 2020 Yves MARTIN. All rights reserved.
//

import SwiftUI


// End High
struct EndHigh: View {
    @EnvironmentObject var user: User
    
    @State var userLastName: String = ""
    @State var userFirstName: String = ""
    @State var userActivityDomain: String = ""
    @State var userAgeRange = ""
    var body: some View {
        VStack {
            HStack {
                Text("Nom")
                Spacer()
            }
            VStack {
                TextField("Saisir votre Nom", text: $user.userLastName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
//                    .cornerRadius(10)
//                    .padding(.leading, 5.0)
//                    .border(Color.gray)
//
//                    .keyboardType(.default)
                    .font(.headline)
            }
            .padding(.top, -10.0)
            .font(.title)
            HStack {
                Text("Prénom")
                Spacer()
            }
            VStack {
                TextField("Saisir votre Prénom", text: $user.userFirstName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
//                    .padding(.leading, 5.0)
//                    .border(Color.gray)
                    .keyboardType(/*@START_MENU_TOKEN@*/.default/*@END_MENU_TOKEN@*/)
                    .font(.headline)
            }
            .padding(.top, -10.0)
            .font(.headline)
            HStack {
                Text("Domaine d'activité")
                Spacer()
            }
            VStack {
                TextField("Saisir votre domaine d'Activité", text: $user.userActivityDomain)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
//                    .padding(.leading, 5.0)
//                    .border(Color.gray)
//                    .keyboardType(/*@START_MENU_TOKEN@*/.default/*@END_MENU_TOKEN@*/)
                    .font(.headline)
            }
            .padding(.top, -10.0)
            .font(.title)
            Spacer()
            HStack {
                Text("Tranche d'âge")
                Spacer()
            }
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .padding(.top, -25.0)
                    .frame(height: 180)
                    .foregroundColor(.gray)
                    .opacity(0.2)
                Picker(selection: $user.userAgeRange, label: Text("")) {
                    Text("18 -> 25").tag("18 -> 25")
                    Text("26 -> 35").tag("26 -> 35")
                    Text("36 -> 45").tag("36 -> 45")
                    Text("46 -> 55").tag("46 -> 55")
                    Text("56 and more").tag("56 and more")
                        .frame(height: 80.0)
                        .foregroundColor(.gray)
                    }.pickerStyle(WheelPickerStyle())
                .font(.callout)
            }
        }
    }
}

struct EndHigh_Previews: PreviewProvider {
    static var previews: some View {
        EndHigh()
        .environmentObject(User.yves)

    }
}


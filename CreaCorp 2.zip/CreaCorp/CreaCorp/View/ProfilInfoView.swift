//
//  ProfilInfoView.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 19/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation
import SwiftUI

struct ProfilInfoView : View
{
    var user : User
    
    var body : some View
    {
        VStack(alignment: .leading, spacing: 10)
        {
            HStack
            {
                ProfilPictureView(picture: user.userImage)
                if user != userAlaaeddine
                {
                    ProfilOptionView()
                }
                
            }
            
//            Text("\(user.userFirstName) \(user.userLastName)").font(.title)
            if user.userProfileType == "MENTOR"
            {
                Text("Mentor").bold().italic().font(.caption).opacity(1)
            }
            else
            {
                Text("Demandeur").bold().italic().font(.caption).opacity(1)
            }
            
            Text(user.userActivityDomain).font(.headline)
            
            HStack
            {
                ButtonImageView(iconLink: "mappin.circle.fill", opacityVal: 0.6)
                
                Text(user.userLocation).opacity(0.6).font(.caption)
            }
        }.padding(20)
    }
}

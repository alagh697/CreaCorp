//
//  PhotoCapture.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 25/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation

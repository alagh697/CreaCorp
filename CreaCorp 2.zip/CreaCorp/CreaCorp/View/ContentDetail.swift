//
//  ContentDetail.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 21/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation
import SwiftUI

struct ContentDetail: View {
    var codeName: String
    var codeTaux: Int
    var body: some View {
        VStack {
            Image(codeName)
                .clipShape(Circle())
            Text("Mentor \(codeName)")
                .font(.title)
                .fontWeight(.bold)
            Text("Matching \(codeTaux)%")
            
        }
    }
}

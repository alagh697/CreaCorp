//
//  ContentRow.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 21/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation
import SwiftUI

struct ContentRow: View {
    
    var match : Match
    
    var body: some View {
        HStack {
            VStack
            {
                
                ProfilPictureView(picture: match.user.userImage)
                
                
                Text("\(match.codeTaux)%") //boutton matching
                    .padding(3)
                    .cornerRadius(10)
                    .frame(width: 80, height: 30)
                    .foregroundColor(Color.white)
                    .background(Color.black)
            }
                   
               
            VStack(alignment: .leading) { //alignement texte+boutons
                
                VStack(alignment: .leading) {
                    
                    VStack (alignment: .leading, spacing: 5.0)
                    {
                        Text("\(match.user.userFirstName) \(match.user.userLastName)")
                                .font(.title)
                                .padding(.top, -8.0)
                        
                        if match.user.userProfileType == "MENTOR"
                        {
                            Text("Mentor").bold().italic().font(.caption).opacity(1)
                        }
                        else
                        {
                            Text("Demandeur").bold().italic().font(.caption).opacity(1)
                        }
                        
                        Text(match.user.userProjectName)
                            .font(.subheadline)
                            .padding(.bottom, 9.0)
              
                    }
                    
                    HStack { //HStack alignement horizontal boutons
                        
                        Button(action: {
                            // Action clic bouton Follow
                        }) {
                            ButtonTextView(btText: "Suivre", backColor: .blue)
                            
                        }
                                           
                        Button(action: {
                            //Action clic bouton
                        }) {
                            ButtonTextView(btText: "Mentorat", backColor: .green)
                           
                        }
                        
                        Button(action: {
                            matchings.remove(at: self.match.indexInList)

                         }) {
                             ButtonTextView(btText: "Supprimer", backColor: .red)
                        
                         }
                        
                    }
                    .padding(.bottom, 0)
                    
                }
                
            }
            Spacer()
        }
        
    }
}

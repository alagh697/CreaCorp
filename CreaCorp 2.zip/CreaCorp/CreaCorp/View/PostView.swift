//
//  File.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 19/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation
import SwiftUI

struct PostView: View
{
    var user : User
    var post : Post
    @State var likeOp = 0.4
    
    var dateTimeFormatter: DateFormatter{
        let formatterDateTime = DateFormatter()
         formatterDateTime.dateFormat = "d/MM/y"
        return formatterDateTime
    }
    
    var body : some View
    {
        VStack(alignment: .leading, spacing: 10)
        {
            HStack
            {
                ProfilPictureView(picture: user.userImage, size: 35)
                
                Text("\(user.userFirstName) \(user.userLastName)").font(.caption).bold()
                Spacer()
                Text("\(post.postDate, formatter: dateTimeFormatter)")
                    .opacity(0.5).font(.caption)
                
            }
            
            Text(post.postText).font(.body)
            
            HStack
            {
                Spacer()
                Button(action: {
                    if self.likeOp == 1
                    {
                        self.likeOp = 0.4
                    }
                    else
                    {
                        self.likeOp = 1
                    }
                })
                {
                    ButtonImageView(iconLink: "hand.thumbsup.fill", opacityVal: likeOp)
                }.buttonStyle(PlainButtonStyle())
                
                Button(action: {})
                {
                    ButtonImageView(iconLink: "message.circle.fill", opacityVal: 0.4)
                }.buttonStyle(PlainButtonStyle())
                
                Button(action: {})
                {
                    ButtonImageView(iconLink: "square.and.arrow.up.fill", opacityVal: 0.4)
                }.buttonStyle(PlainButtonStyle())
                
            }
            
            
        }
    }
}

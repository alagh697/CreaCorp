//
//  boutdecode.swift
//  test
//
//  Created by grégory paradis on 25/02/2020.
//  Copyright © 2020 grégory paradis. All rights reserved.
//

import SwiftUI

struct boutdecode: View {
    @State var showImagePicker: Bool = false
     @State var image: Image? = nil
    var body: some View {
        VStack {
            // ---------------------------------------
            ZStack{
                
                
                Circle()
                    .fill(Color.white)
                    .frame(width: 127, height: 127)
                    .overlay(Circle().stroke(lineWidth: 2))
                    .gesture(
                        TapGesture()
                            .onEnded { _ in
                                self.showImagePicker.toggle()
                        }
                )
                
                Image (systemName: "person.crop.circle.badge.plus")
                    .scaleEffect(1.5)
                
                
                image?.resizable()
                    .frame(width: 127, height: 127)
                    .clipShape(Circle())
                    //.shadow(radius: 10)
                    .overlay(Circle().stroke(Color(red: 251/255, green: 129/255, blue: 34/255),lineWidth: 2))
            }
            .foregroundColor(Color(red: 251/255, green: 129/255, blue: 34/255))
            
            Button(action: {
                withAnimation {
                    self.showImagePicker.toggle()
                }
            }) {
                
                if image != nil {
                    Text("changer photo").foregroundColor(Color(red: 251/255, green: 129/255, blue: 34/255))
                }else{
                    Text("choisir photo").foregroundColor(Color(red: 251/255, green: 129/255, blue: 34/255))
                }
            }
        }
        .sheet(isPresented: $showImagePicker) {
            ImagePicker(image: self.$image)
        }
    }
}

struct boutdecode_Previews: PreviewProvider {
    static var previews: some View {
        boutdecode()
    }
}

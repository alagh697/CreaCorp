//
//  NewPostView.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 20/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation
import SwiftUI

struct NewPostView: View
{
    var user : User
    
    @State var newPostText: String = ""
    
    var body: some View
    {
        VStack
        {
            Text("")
            .navigationBarTitle("Discussions")
                .navigationBarItems(trailing: NavigationLink(destination: NewsFeedView(user: user))
                {
                    Button(action: {
                        self.user.addPost(post: Post(postText: self.newPostText))
                    })
                    {
                        ButtonTextView(btText: "Valider", backColor: .blue)
                            
                    }.buttonStyle(PlainButtonStyle())
                })
            
            HStack
            {
                ProfilPictureView(picture: user.userImage)
                
                TextField("Exprimez vous...", text: $newPostText)//.textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            }
            
            Spacer()
        }.padding()
    }
}

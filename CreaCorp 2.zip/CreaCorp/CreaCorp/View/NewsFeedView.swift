//
//  NewsFeedView.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 20/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation
import SwiftUI

struct NewsFeedView : View
{
    @State var user : User
    
    var filters = ["Abonnements", "Mentorat"]
    @State var filterSelected = 0
    @State var newPostText: String = ""
    
    var body : some View
    {
        VStack
        {
            
            HStack
            {
                ProfilPictureView(picture: user.userImage)
                
                TextField("Exprimez vous...", text: $newPostText )
                .padding(5)
                .background(Color.gray)
                .foregroundColor(.white)
                .opacity(0.9)
                .cornerRadius(10)
                    
                
                Button(action: {
                    self.user.addPost(post: Post(postText: self.newPostText))
                    self.newPostText=""
                })
                {
                    ButtonImageView(iconLink: "pencil.circle.fill", opacityVal: 1)
                        
                }.buttonStyle(PlainButtonStyle())
                .disabled(self.newPostText.isEmpty)
                
//                NavigationLink(destination: NewPostView(user: user))
//                {
//                    HStack
//                    {
//                        ButtonTextView(btText: "Exprimez vous", backColor: .gray, opacityVal: 0.3)
//                        ButtonImageView(iconLink: "pencil.circle.fill", opacityVal: 0.5)
//                    }
//
//
//                }.buttonStyle(PlainButtonStyle())
                
                Spacer()
            }
            
            Picker(selection: $filterSelected, label: Text("Platform"))
            {
                ForEach(0 ..< filters.count)
                {
                    Text(self.filters[$0])
                }
            }.pickerStyle(SegmentedPickerStyle())
            
           NewsFeedListView(user: user)
        }.padding()
        .navigationBarTitle("Actualités")
    }
}

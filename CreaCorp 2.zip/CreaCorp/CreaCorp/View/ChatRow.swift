//
//  ChatRow.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 24/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation

import SwiftUI

struct ChatRow: View {
    
    var chat : Chat
    
    var body: some View {
        HStack {
            VStack {
                ProfilPictureView(picture: chat.chatAdmin.userImage)
                
                
            }
                   
               
            VStack(alignment: .leading) { //alignement texte+boutons
                
                VStack(alignment: .leading, spacing: 5.0)
                {
                    Text("\(chat.chatAdmin.userFirstName) \(chat.chatAdmin.userLastName)")
                            .font(.title)
                            .padding(.top, -8.0)
                    
                    Text(chat.chatMessages[chat.chatMessages.count-1].messageText)
                        .font(.subheadline)
                        .padding(.bottom, 9.0)
                    
                    
                }
                
            }
            Spacer()
        }
    }
}

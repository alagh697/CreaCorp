//
//  Data.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 21/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation
import SwiftUI

/*let matchings = [Mentor (id: 1001, codeName:"Amandine Liu", codeTaux: 92),
                Mentor (id: 1002, codeName:"Jo Mery", codeTaux: 90),
                Mentor (id: 1003, codeName:"Manu Privet", codeTaux: 85),
                Mentor (id: 1004, codeName:"Patrick Durand", codeTaux: 76),
                Mentor (id: 1005, codeName:"Bertrand Lemark", codeTaux: 65),
                Mentor (id: 1006, codeName:"Emma Swan", codeTaux: 35)]*/
let userAlaaeddine = User(firstname: "Georges", lastname: "Metin", description: "Developper recherche mentor", profilPicture: "Georges Metin", mentor: "DEMANDEUR", location: "Paris", projectName: "Conception web", projectDescription: "Projet agence web web",projectWebsite:"www.atlantisdev.com", projectPP: "Atlantisdev")
    
//User(firstname: "Alaaeddine", lastname: "GHARBI", description: "Développeur iOS", profilPicture: "Alaaeddine Gharbi", mentor: "DEMANDEUR", location: "Lyon", projectName: "Capatchi", projectDescription: "Lire les captcha automatiquement.", projectWebsite: "www.capatchi.com", projectPP: "CreaCorp")

//let usersSample = [
//User(firstname: "Amandine", lastname: "Liu", description: "Mortal Kombat fighter", profilPicture: "Amandine Liu", mentor: "MENTOR", location: "Paris", projectName: "Mortal Kombat", projectDescription: "Tournoi à mort.",projectWebsite:"www.mortalkombat.com", projectPP: "Mortal Kombat"),
//User(firstname: "Jo", lastname: "Mery", description: "Street Fighter fighter", profilPicture: "Jo Mery", mentor: "MENTOR", location: "Lyon", projectName: "Street Fighter", projectDescription: "Combat de rue.",projectWebsite:"www.streetfighter.com", projectPP: "Street Fighter" ),
//User(firstname: "Manu", lastname: "Privet", description: "Tekken fighter", profilPicture: "Manu Privet", mentor: "MENTOR", location: "Paris" , projectName: "Tekken", projectDescription: "Tournoi du poing de fer.",projectWebsite:"www.tekken.com", projectPP: "Tekken"),
//User(firstname: "Emma", lastname: "Swan", description: "Nioh fighter", profilPicture: "Emma Swan", mentor: "MENTOR", location: "Marseille", projectName: "Nioh", projectDescription: "Chasse aux démons.",projectWebsite:"www.nioh.com", projectPP: "Nioh" )
//
//
//]

var usersSample = [


User(firstname: "Bertand", lastname: "Lemark", description: "Societe Atom", profilPicture: "Bertrand Lemark", mentor: "MENTOR", location: "Paris" , projectName: "Aide aux projets", projectDescription: "Finances, concept, marketing.",projectWebsite:"www.atomesarl.com", projectPP: "Atome"),

User(firstname: "Jo", lastname: "Mery", description: "Community Management", profilPicture: "Jo Mery", mentor: "MENTOR", location: "Marseille", projectName: "Développement télécommunication", projectDescription: "développement d'aide à la communication entreprise.",projectWebsite:"www.circlecommunity.com", projectPP: "CircleCommunity"),

User(firstname: "Nicolas", lastname: "Presat", description: "Menuisier", profilPicture: "Nicolas Presat", mentor: "DEMANDEUR", location: "Marseille", projectName: "Construction de masse", projectDescription: "Création usine de menuiserie .",projectWebsite:"www.lemenuisierdusud.com", projectPP: "noLogo"),

User(firstname: "Amilie", lastname: "Mercy", description: "Menuisier", profilPicture: "Amilie Mercy", mentor: "DEMANDEUR", location: "Toulon", projectName: "Culture Bio", projectDescription: "Developpement maraîcher.",projectWebsite:"www.dubiodetoulon.com", projectPP: "noLogo"),

User(firstname: "Manu", lastname: "Privet", description: "Ingenierie et modelisation", profilPicture: "Manu Privet", mentor: "MENTOR", location: "Lyon", projectName: "Aide aux projets", projectDescription: "Lancer et aider les demandeurs d'emplois à envisager leur projets",projectWebsite:"www.lotuscouture.com", projectPP: "ADNlogo" ),
User(firstname: "Alaaeddine", lastname: "GHARBI", description: "Développeur iOS", profilPicture: "Alaaeddine Gharbi", mentor: "MENTOR", location: "Lyon", projectName: "Capatchi", projectDescription: "Lire les captcha automatiquement.", projectWebsite: "www.capatchi.com", projectPP: "CreaCorp"),
User(firstname: "Amendine", lastname: "Liu", description: "Couturière spécialisée Artistes", profilPicture: "Amendine Liu", mentor: "MENTOR", location: "Lyon", projectName: "Couturière", projectDescription: "Conceptualisation de projets.",projectWebsite:"www.lotuscouture.com", projectPP: "LotusCouture" ),
User(firstname: "Jessim", lastname: "Cheurfa", description: "Développeur web cherche mentor", profilPicture: "Jessim Cheurfa", mentor: "DEMANDEUR", location: "Vaulx-en-Velin", projectName: "Work it", projectDescription: "Simuler votre création d'entreprise.", projectWebsite: "www.work-it.com", projectPP: "workit")
]

var matchings = [
    Match(user: usersSample[0], codeTaux: 92, indexInList: 0),
    Match(user: usersSample[1],codeTaux: 90, indexInList: 1),
    Match(user: usersSample[2],codeTaux: 85, indexInList: 2),
    Match(user: usersSample[3],codeTaux: 35, indexInList: 3),
    Match(user: usersSample[4],codeTaux: 20, indexInList: 4),
    Match(user: usersSample[5],codeTaux: 10, indexInList: 5),
    Match(user: usersSample[6],codeTaux: 20, indexInList: 6),
    Match(user: usersSample[7],codeTaux: 20, indexInList: 7)]


var messagesSampleLiu = [
    Message(messageSender: userAlaaeddine, messageReceiver: usersSample[6], messageText: "Bonjour!"),
    Message(messageSender: usersSample[6], messageReceiver: userAlaaeddine, messageText: "Salut"),
    Message(messageSender: userAlaaeddine, messageReceiver: usersSample[6], messageText: "Je cherche une personne pouvant m'aider à réaliser mon projet de création d'entreprise dans le développement informatique."),
    Message(messageSender: usersSample[6], messageReceiver: userAlaaeddine, messageText: "Désolé je ne pense pas être la mieux placé pour vous aider car je ne suis pas du tout dans l'informatique."),
    Message(messageSender: userAlaaeddine, messageReceiver: usersSample[6], messageText: "Merci quand même")
]

var messagesSampleJo = [
    Message(messageSender: userAlaaeddine, messageReceiver: usersSample[0], messageText: "Bonjour!"),
    Message(messageSender: usersSample[0], messageReceiver: userAlaaeddine, messageText: "Salut"),
    Message(messageSender: userAlaaeddine, messageReceiver: usersSample[0], messageText: "Je cherche une personne pouvant m'aider à réaliser mon projet de création d'entreprise dans le développement informatique."),
    Message(messageSender: usersSample[0], messageReceiver: userAlaaeddine, messageText: "Je peux vous aider j'ai créer mon entreprise de développement informatique il y a 5 ans en étant demandeur d'emploi."),
    Message(messageSender: userAlaaeddine, messageReceiver: usersSample[0], messageText: "Merci")
]

var chatSample = [
Chat(chatAdmin: usersSample[0], chatMessages: messagesSampleJo),
Chat(chatAdmin: usersSample[6], chatMessages: messagesSampleLiu)
]






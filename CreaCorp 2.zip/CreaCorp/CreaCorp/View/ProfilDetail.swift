//
//  ProfilDetail.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 19/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation
import SwiftUI

struct ProfilDetailView: View
{
    var user : User
    
    var body : some View
    {
        
        Form
        {
            VStack(alignment: .leading, spacing: 5)
            {
                
                if user == userAlaaeddine
                {
                    Text("")
                    .navigationBarItems(trailing:
                    NavigationLink(destination: SettingsView(user: user))
                    {
                        ButtonImageView(iconLink: "gear", opacityVal: 1)
                            
                    }.buttonStyle(PlainButtonStyle()))
                }
                
                
                
                ProfilInfoView(user: user)
                
                Spacer()
                
                ProjectInfoView(user: user)
                
                Spacer()
                
                Text("Actualités").font(.caption).bold().padding()
                NewsFeedListView(user: user)
                
            }.navigationBarTitle("\(user.userFirstName) \(user.userLastName)")
                
        }
    }
}

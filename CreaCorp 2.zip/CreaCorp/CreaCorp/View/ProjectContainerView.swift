//
//  ProjectContainerView.swift
//  CreaCorp Yv
//
//  Created by Yves MARTIN on 21/02/2020.
//  Copyright © 2020 Yves MARTIN. All rights reserved.
//

import SwiftUI



// Navigation : Page View
struct ProjectContainerView: View {
    //@State var currentUser: User = User.yves
    @ObservedObject var currentUser: User = User.yves
    @ObservedObject var questionList = QuestionList()
    
    var body: some View {
        let answerList = questionList.convertQuestionToAnswer()
        currentUser.answerAssign(answers: answerList)
        return 
            VStack {
                HeaderMid(userProfileType: $currentUser.userProfileType)
                HeaderSup(userProfilCompletion: currentUser.userProfilCompletion)
                HeaderInf(userProfileType: currentUser.userProfileType)
                SeparateShadow()
                ListQuestionView()
                .environmentObject(currentUser)
                .environmentObject(questionList)
            }
            .padding()
                .navigationBarTitle("Inscription") // Titre de la page courante
        
    }
}

struct ProjectContainerView_Previews: PreviewProvider {
    static var previews: some View {
        ProjectContainerView()
    }
}

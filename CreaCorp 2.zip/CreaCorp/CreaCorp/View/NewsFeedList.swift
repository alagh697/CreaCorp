//
//  NewsFeedList.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 19/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation
import SwiftUI

struct NewsFeedListView : View
{
    var user : User
    
    var body: some View
    {
        VStack(alignment: .leading)
        {
            
            List(user.posts)
            {
                post in
                PostView(user: self.user, post: post)
                
            }
        }
        
        
    }
}

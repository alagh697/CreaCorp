//
//  SettingsView.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 21/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation
import SwiftUI

struct SettingsView : View
{
    var user : User
    
    var body : some View
    {
        VStack
        {
            Text("")
            .navigationBarTitle("Paramètres")
                .navigationBarItems(trailing: NavigationLink(destination: WelcomeView(user: user))
                {
                    ButtonImageView(iconLink: "power", opacityVal: 1)
                        
                }.buttonStyle(PlainButtonStyle()))
        }
        
        
    
    }
}

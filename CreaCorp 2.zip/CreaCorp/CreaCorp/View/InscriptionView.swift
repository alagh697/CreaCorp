//
//  InscriptionView.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 20/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation
import SwiftUI

struct InscriptionView : View
{
    var user : User
    
    var body : some View
    {
           ProjectContainerView()
    }
}

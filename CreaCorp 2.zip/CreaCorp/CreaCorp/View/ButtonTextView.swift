//
//  ButtonTextView.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 20/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation
import SwiftUI

struct ButtonTextView : View
{
    var btText: String
    var backColor: Color
    var opacityVal: Double = 1
    
    var body : some View
    {
        Text(btText)
        .padding(4)
        .foregroundColor(Color.white)
        .background(backColor)
        .cornerRadius(10)
        .shadow(radius:4)
        .opacity(opacityVal)
    }
}

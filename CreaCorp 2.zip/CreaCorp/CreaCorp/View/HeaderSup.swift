//
//  HeaderSup.swift
//  CreaCorp Yv
//
//  Created by Yves MARTIN on 21/02/2020.
//  Copyright © 2020 Yves MARTIN. All rights reserved.
//

import SwiftUI



// Header Supérieur
struct HeaderSup: View {
    var userProfilCompletion: Int
    
    var body: some View {
        
        return HStack {
            Text("Réponses aux questions :")
                .font(.headline)
                .fontWeight(.regular)
            //            Spacer()
            Text(" \(userProfilCompletion) %")
                .font(.title)
                .fontWeight(.bold)
        }
            
        .frame(width: 400, height: 20.0)
        .padding(.bottom, 9.0)
    }
}











struct HeaderSup_Previews: PreviewProvider {
    static var previews: some View {
        HeaderSup(userProfilCompletion: 0)
    }
}



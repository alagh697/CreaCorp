//
//  ProjectInfoView.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 19/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation
import SwiftUI

struct ProjectInfoView : View
{
    var user : User
    
    var body : some View
    {
        VStack(alignment: .leading, spacing: 10)
        {
            Image(user.userProjectLogo)
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(height: 80, alignment: .top)
            
            
            HStack
            {
                Text(user.userProjectName).bold()
                
                if user.userProfileType == "MENTOR"
                {
                    Text("Entreprise").bold().italic().font(.caption).opacity(1)
                }
                else
                {
                    Text("Projet").bold().italic().font(.caption).opacity(1)
                }
            }
            
            HStack
            {
                Image(systemName: "globe")
                .resizable()
                .frame(width: 20, height: 20, alignment: .top)
                .cornerRadius(100)
                .opacity(0.3)
                
             
                Text(user.userProjectWebsite).opacity(0.7).font(.caption)
                    .foregroundColor(.blue)
                .onTapGesture
                {
                    let http = "http://"
                    let formattedString = http + self.user.userProjectWebsite
                    let url = URL(string: formattedString)!
                    UIApplication.shared.open(url)
                }
                
        
            }
            
            Text(user.userProjectDescription).font(.caption)
        }
        .padding(20)
        
    }
}


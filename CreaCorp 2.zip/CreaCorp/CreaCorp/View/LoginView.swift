//
//  LoginView.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 21/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation
import SwiftUI

struct LoginView: View
{
    var theUser: User
    
    @State var email: String = ""
    @State var password: String = ""
    
    @ObservedObject private var kGuardian = KeyboardGuardian(textFieldCount: 2)
    
    var body: some View
    {
        VStack(alignment: .leading)
        {
            Text("Email").bold()
            TextField("Email", text: $email)
                .padding(5)
                .background(Color.gray)
                .foregroundColor(.white)
                .opacity(0.9)
                .cornerRadius(10)
            .background(GeometryGetter(rect: $kGuardian.rects[1]))
                
            
            Text("Mot de passe").bold()
            SecureField("Mot de passe", text: $password)
            .padding(5)
            .background(Color.gray)
            .foregroundColor(.white)
            .opacity(0.9)
            .cornerRadius(10)
            .background(GeometryGetter(rect: $kGuardian.rects[0]))
            
            
        }.offset(y: kGuardian.slide).animation(.easeInOut(duration: 1))
            .onAppear() {
                self.kGuardian.addObserver()
            }
        .onDisappear() {
            self.kGuardian.removeObserver()
        }
    }
}

//
//  ButtonImageView.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 20/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation
import SwiftUI

struct ButtonImageView : View
{
    var iconLink: String
    var opacityVal: Double
    
    var body : some View
    {
        Image(systemName: iconLink)
        .resizable()
        .aspectRatio(contentMode: .fill)
        .frame(width: 30, height: 30, alignment: .top)
        .cornerRadius(100)
        .opacity(opacityVal)
        .shadow(radius: 3)
        
    }
}

//
//  Match.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 24/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation

struct Match: Identifiable{
    var id = UUID()
    //var codeName: String
    var user: User = User(userProfileType: "DEMANDEUR")
    var codeTaux: Int
    var indexInList: Int
   
}

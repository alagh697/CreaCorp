//
//  Post.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 19/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation

struct Post : Identifiable
{
    var id = UUID()
    //var user = User()
    var postText = ""
    var postDate = Date()
    
    /*let df = DateFormatter()
    df.dateFormat = "yyyy-MM-dd hh:mm:ss"
    let now = df.stringFromDate(Date())*/
    
}

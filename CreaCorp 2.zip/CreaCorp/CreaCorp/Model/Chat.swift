//
//  Chat.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 24/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation

struct Chat : Identifiable
{
    var id = UUID()
    var chatAdmin : User = User(userProfileType: "MENTOR")
    var chatDate = Date()
    
    var chatMessages : [Message]
    
    mutating func addMessage(message: Message)
    {
        self.chatMessages.append(message)
    }
}

//
//  File.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 24/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation

struct Message : Identifiable
{
    var id = UUID()
    var messageSender = User(userProfileType: "MENTOR")
    var messageReceiver = User(userProfileType: "DEMANDEUR")
    var messageText = ""
    var messageDate = Date()
}

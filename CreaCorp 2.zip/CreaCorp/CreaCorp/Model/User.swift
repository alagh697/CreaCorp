//
//  User.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 19/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import Foundation
import SwiftUI

//Données d'échange interne & externe
class User: ObservableObject, Identifiable, Comparable{
    static func < (lhs: User, rhs: User) -> Bool {
        return false
    }
    
    static func == (lhs: User, rhs: User) -> Bool {
        return lhs.userFirstName == rhs.userFirstName && lhs.userLastName == rhs.userLastName
    }
    
    
    var id = UUID()
    @Published var userId = ""
    @Published var userLastName = ""
    @Published var userFirstName = ""
    @Published var userPhoneNumber = ""
    @Published var userEmail = ""
    var userProfilCompletion: Int = 0
    @Published var userProfileType = ""
    @Published var userActivityDomain = ""
    @Published var userAgeRange = "18 -> 25"
    @Published var userProjectName = ""
    @Published var userProjectDescription = ""
    @Published var userProjectWebsite = ""
    @Published var userImage = ""
    @Published var userProjectLogo = ""
    @Published var userImageDL: Image? = nil
    @Published var userProjectLogoDL: Image? = nil
    @Published var userLocation = ""
    var userAnsQ1 = ""
    var userAnsQ2 = ""
    var userAnsQ3 = ""
    var userAnsQ4 = ""
    var userAnsQ5 = ""
    var userAnsQ6 = ""
    var userAnsQ7 = ""
    var userAnsQ8 = ""
    var userAnsQ9 = ""
    var userAnsQ10 = ""
    
    @Published var posts = [
        Post( postText: "Bonjour! Je cherche une personne pouvant m'aider à réaliser mon projet de création d'entreprise dans le développement informatique."),
        Post( postText: "Le projet avance très bien."),
        Post( postText: "Si vous êtes mentor dans le développement informatique contactez moi je recherche une personne pour m'aider."),
        Post( postText: "Visitez le site du projet."),
        Post( postText: "Merci à mon mentor pour son aide.")
        ]
    
    func addPost(post: Post)
    {
        self.posts.append(post)
    }
    
    func answerAssign(answers: [String]) {
        self.userAnsQ1 = answers[0]
        self.userAnsQ2 = answers[1]
        self.userAnsQ3 = answers[2]
        self.userAnsQ4 = answers[3]
        self.userAnsQ5 = answers[4]
        self.userAnsQ6 = answers[5]
        self.userAnsQ7 = answers[6]
        self.userAnsQ8 = answers[7]
        self.userAnsQ9 = answers[8]
        self.userAnsQ10 = answers[9]
        
        let answersExisting: [String] = answers
            .filter { answer in
                answer.isEmpty == false
        }
                let nbOfAnswers: Int = answersExisting.count
        let nbOfQuestions: Int = answers.count
        self.userProfilCompletion = Int((100 * Double(nbOfAnswers) / Double(nbOfQuestions)))
        print()
    }
    
    
    init(firstname: String, lastname: String, description: String, profilPicture: String, mentor: String, location: String, projectName: String, projectDescription: String, projectWebsite: String, projectPP: String)
    {
        self.userFirstName = firstname
        self.userLastName = lastname
        self.userActivityDomain = description
        self.userImage = profilPicture
        self.userProfileType = mentor
        self.userLocation = location
        self.userProjectName = projectName
        self.userProjectDescription = projectDescription
        self.userProjectWebsite = projectWebsite
        self.userProjectLogo = projectPP
    }
    
    init(userProfileType: String) {
        self.userProfileType = userProfileType
    }
    static let yves = User(userProfileType: "Mentor")
    static let olga = User(userProfileType: "Demandeur")
    
    
    
    //    @Published var completion: Double {
    //        return nbQuestoin / totalQuestion
    //    }
}

// fonction pour bouton de test d'une variable
// User =====================================
func checkUserValue(user: User) {
    print(user.userAnsQ2)
}
//===================================


//struct User : Identifiable
//{
//
//
//    var id = UUID()
//    var firstname : String = "Alaaeddine"
//    var lastname : String = "GHARBI"
//    var description : String = "iOS Développeur"
//    var profilPicture : String = "Alaaeddine Gharbi"
//    var mentor : Bool = false
//    var location : String = "Lyon"
//    var email : String = ""
//    var password : String = ""
//    var projectName : String = "Capatchi"
//    var projectDescription : String = "Lire les capatchi automatiquement."
//    var projectWebsite : String = "capatchi.com"
//    var projectPP : String = "CreaCorp"
//
//    var posts = [
//    Post( postText: "Bonjour!"),
//    Post( postText: "Au revoir!")
//    ]
//

//}

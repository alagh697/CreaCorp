//
//  ContentView.swift
//  CreaCorp
//
//  Created by Alaaeddine Gharbi on 19/02/2020.
//  Copyright © 2020 Alaaeddine Gharbi. All rights reserved.
//

import SwiftUI

struct ContentView: View
{
    //var theUser = User(userProfileType: "DEMANDER")
    
    
    /*var theProject = Project(projectName: "Capatchi", projectDescription: "Lire un capatchi.", projectWebsite: "capatchi.com")
    
    var theUser = User(firstname: "Alaaeddine", lastname: "GHARBI", description: "Développeur iOS", profilPicture: "eye.fill", mentor: false, project: theProject)*/
    
    var body: some View
    {
        NavigationView
        {
            WelcomeView(user: userAlaaeddine)
            //.environmentObject(theUser)
            
        }
        
        //ProfilDetailView(user: theUser)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
